document.getElementById("detailsBtn").addEventListener("click", () => {
  const details = document.getElementById("details");
  details.classList.toggle("hidden");
});
