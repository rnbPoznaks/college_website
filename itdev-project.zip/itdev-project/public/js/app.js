document.addEventListener('DOMContentLoaded', () => {
  gsap.from('header', { duration: 1, y: -100, opacity: 0 });
  gsap.from('nav',    { duration: 1, x: -200, opacity: 0, delay: 0.5 });

  const navUl       = document.querySelector('.site-nav ul');
  const currentUser = JSON.parse(localStorage.getItem('currentUser') || 'null');

  if (!navUl) return;

  ['login.html','register.html'].forEach(href => {
    const a = navUl.querySelector(`a[href="${href}"]`);
    if (a) a.parentElement.remove();
  });

  if (currentUser) {
    const liUser = document.createElement('li');
    liUser.innerHTML = `<a href="dashboard.html">${currentUser.username}</a>`;
    navUl.append(liUser);
  }
  else {
    ['login.html','register.html'].forEach((href, i) => {
      const li = document.createElement('li');
      li.innerHTML = `<a href="${href}">${i===0?'Вход':'Регистрация'}</a>`;
      navUl.append(li);
    });
  }

  const liTheme = document.createElement('li');
  liTheme.classList.add('theme-toggle');
  const btn = document.createElement('button');
  btn.id = 'theme-toggle';
  const saved = localStorage.getItem('theme') === 'dark';
  if (saved) document.body.classList.add('dark');
  btn.textContent = saved ? '☀️' : '🌙';
  liTheme.append(btn);
  navUl.append(liTheme);

  btn.addEventListener('click', () => {
    const isDark = document.body.classList.toggle('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    btn.textContent = isDark ? '☀️' : '🌙';

    if (window.pJSDom && pJSDom[0]) {
      pJSDom[0].pJS.fn.vendors.destroy();
      initParticles();
    }
  });

  function initParticles() {
    particlesJS('particles-bg', {
      particles: {
        number:   { value: 80 },
        size:     { value: 3 },
        move:     { speed: 1 },
        line_linked: {
          enable:   true,
          distance: 120,
          color:    document.body.classList.contains('dark')
                    ? '#8ac6d1'
                    : '#2a9d8f',
          opacity:  0.4,
          width:    1
        }
      }
    });
  }
  initParticles();

  const greeting = document.querySelector('.intro .greeting');
  greeting.textContent = new Date().getHours() < 12
    ? 'Доброе утро,' : 'Добрый день,';
  gsap.from(greeting, { opacity: 0, y: -20, duration: 0.8 });

  const txt = "Создаём продукты, которые впечатляют и работают";
  const el  = document.getElementById('tagline');
  setTimeout(() => {
    let i = 0;
    el.textContent = '';
    (function type() {
      if (i < txt.length) {
        el.textContent += txt.charAt(i++);
        setTimeout(type, 50);
      }
    })();
  }, 500);

  gsap.registerPlugin(ScrollTrigger);

  document.getElementById('hero-cta')
    ?.addEventListener('click', () => window.location = 'order.html');
  document.getElementById('support-btn')
    ?.addEventListener('click', () => window.Intercom && Intercom('show'));
});
