const express       = require('express');
const session       = require('express-session');
const SQLiteStore   = require('connect-sqlite3')(session);
const sqlite3       = require('sqlite3').verbose();
const bcrypt        = require('bcrypt');
const path          = require('path');
const fs            = require('fs');

const app = express();

const dataDir = path.join(__dirname, 'db');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'database.db');
const db = new sqlite3.Database(
  dbPath,
  sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE,
  err => {
    if (err) console.error('Ошибка при открытии БД:', err.message);
    else     console.log('БД открыта:', dbPath);
  }
);

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      username    TEXT    UNIQUE NOT NULL,
      password    TEXT    NOT NULL,
      role        TEXT    DEFAULT 'user',
      created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `, err => {
    if (err) console.error('Ошибка при создании users:', err);
  });

  db.get(`SELECT COUNT(*) AS cnt FROM users WHERE role = 'admin'`, (e, row) => {
    if (!e && row.cnt === 0) {
      bcrypt.hash('admin', 10).then(hash => {
        db.run(
          `INSERT INTO users (username, password, role) VALUES (?,?,?)`,
          ['Emir', hash, 'admin']
        );
      });
    }
  });
});
db.on('trace', sql => console.log('SQL:', sql));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: dataDir }),
  secret: 'ваш_секретный_ключ',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 } 
}));
app.use((req, res, next) => {
  res.locals.userId   = req.session.userId;
  res.locals.username = req.session.username;
  res.locals.role     = req.session.role;    
  res.locals.path     = req.path;
  next();
});

function checkAuth(req, res, next) {
  if (req.session.userId) return next();
  res.redirect('/login');
}

app.get('/',        (req, res) => res.sendFile(path.join(__dirname, 'public/index.html')));
app.get('/about',   (req, res) => res.sendFile(path.join(__dirname, 'public/about.html')));
app.get('/services',(req, res) => res.sendFile(path.join(__dirname, 'public/services.html')));
app.get('/process', (req, res) => res.sendFile(path.join(__dirname, 'public/process.html')));
app.get('/order',   (req, res) => res.sendFile(path.join(__dirname, 'public/order.html')));

app.get('/register', (req, res) => {
  res.render('register', { error: null, success: null });
});

app.post('/register', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.render('register', {
      error: 'Все поля обязательны',
      success: null
    });
  }

  try {
    const hash = await bcrypt.hash(password, 10);

    db.run(
      `INSERT INTO users (username, password) VALUES (?, ?)`,
      [username, hash],
      function (err) {
        if (err) {
          console.error('Ошибка INSERT:', err.message);
          return res.render('register', {
            error: 'Имя уже занято',
            success: null
          });
        }

        return res.render('register', {
          error: null,
          success: 'Регистрация прошла успешно! Теперь войдите в систему.'
        });
      }
    );
  } catch (e) {
    console.error('Ошибка при регистрации:', e);
    return res.render('register', {
      error: 'Внутренняя ошибка сервера',
      success: null
    });
  }
});

app.get('/login', (req, res) => {
  res.render('login', { error: null });
});
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.render('login', { error: 'Введите логин и пароль' });
  }
  db.get(`SELECT * FROM users WHERE username = ?`, [username], async (err, user) => {
    if (err) {
      console.error('Ошибка SELECT:', err.message);
      return res.render('login', { error: 'Ошибка сервера' });
    }
    if (!user) {
      return res.render('login', { error: 'Неверные учётные данные' });
    }
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.render('login', { error: 'Неверные учётные данные' });
    }
    req.session.userId   = user.id;
    req.session.username = user.username;
    req.session.role     = user.role;       
    res.redirect('/dashboard');
  });
});

app.get('/dashboard', checkAuth, (req, res) => {
  db.get(
    `SELECT id, username, role, created_at
     FROM users WHERE id = ?`,
    [req.session.userId],
    (err, user) => {
      if (err || !user) {
        console.error('Ошибка профиля:', err?.message);
        return res.redirect('/login');
      }
      res.render('dashboard', { user });
    }
  );
}); 

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/login');
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});

