const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('db/database.db');

db.serialize(() => {
  db.each("SELECT id, username, role, created_at FROM users", (err, row) => {
    if (err) console.error(err);
    else console.log(row);
  });
});
db.close();
